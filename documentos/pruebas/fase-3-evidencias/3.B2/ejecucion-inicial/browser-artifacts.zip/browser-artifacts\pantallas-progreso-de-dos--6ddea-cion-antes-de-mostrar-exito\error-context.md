# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pantallas.spec.mjs >> progreso de dos bloques espera ACK y finalizacion antes de mostrar exito
- Location: pantallas.spec.mjs:63:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByText(/recibido por el servidor/)
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for getByText(/recibido por el servidor/)
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - banner [ref=e4]:
      - generic [ref=e5]:
        - generic [ref=e6]: LATINOAMÉRICA
        - generic [ref=e7]: Importanto y Exportando el Mundo
      - generic [ref=e8]:
        - generic [ref=e9]: Mario Prueba
        - button "Cerrar sesión" [ref=e10]
    - generic [ref=e11]:
      - navigation "Menú principal" [ref=e12]:
        - list [ref=e13]:
          - listitem [ref=e14]:
            - link "Inicio" [ref=e15] [cursor=pointer]:
              - /url: /inicio
          - listitem [ref=e19]:
            - link "Mi bandeja" [ref=e20] [cursor=pointer]:
              - /url: /bandeja
          - listitem [ref=e24]:
            - link "Pedidos" [ref=e25] [cursor=pointer]:
              - /url: /pedidos
      - main [ref=e30]:
        - generic [ref=e31]:
          - link "Pedidos" [ref=e32] [cursor=pointer]:
            - /url: /pedidos
          - generic [ref=e33]:
            - generic [ref=e34]:
              - heading "DK-EC-2026-0001" [level=1] [ref=e35]
              - generic [ref=e36]: A · Ecuador
              - generic [ref=e37]: A tiempo · vence 20 oct 2026, 16:00
            - paragraph [ref=e38]: Pedido ficticio de lámparas
            - paragraph [ref=e39]: Descripción ficticia
            - paragraph [ref=e40]: Creado por Admin Prueba el 14 oct 2026, 09:00 · versión 1 del flujo
          - list "Recorrido del pedido DK-EC-2026-0001" [ref=e42]:
            - listitem [ref=e43]:
              - button "A1 Crear solicitud de pedido, completada" [ref=e45]:
                - generic [ref=e49]: A1
                - generic [ref=e50]: Crear solicitud de pedido
                - generic [ref=e51]: 15-oct
            - listitem [ref=e52]:
              - button "A2 Codificación, etapa actual" [pressed] [ref=e54]:
                - generic [ref=e55]: "2"
                - generic [ref=e56]: A2
                - generic [ref=e57]: Codificación
                - generic [ref=e58]: Etapa actual
            - listitem [ref=e59]:
              - button "A3 Revisión y aprobación, pendiente" [ref=e61]:
                - generic [ref=e62]: "3"
                - generic [ref=e63]: A3
                - generic [ref=e64]: Revisión y aprobación
            - listitem [ref=e65]:
              - button "A4 Análisis y gestión, pendiente" [ref=e67]:
                - generic [ref=e68]: "4"
                - generic [ref=e69]: A4
                - generic [ref=e70]: Análisis y gestión
            - listitem [ref=e71]:
              - button "A5 Fabricación, pendiente" [ref=e73]:
                - generic [ref=e74]: "5"
                - generic [ref=e75]: A5
                - generic [ref=e76]: Fabricación
            - listitem [ref=e77]:
              - button "A6 Embarque, pendiente" [ref=e79]:
                - generic [ref=e80]: "6"
                - generic [ref=e81]: A6
                - generic [ref=e82]: Embarque
            - listitem [ref=e83]:
              - button "A7 Tránsito, pendiente" [ref=e85]:
                - generic [ref=e86]: "7"
                - generic [ref=e87]: A7
                - generic [ref=e88]: Tránsito
            - listitem [ref=e89]:
              - button "A8 Aduana, pendiente" [ref=e91]:
                - generic [ref=e92]: "8"
                - generic [ref=e93]: A8
                - generic [ref=e94]: Aduana
            - listitem [ref=e95]:
              - button "A9 Bodega, pendiente" [ref=e97]:
                - generic [ref=e98]: "9"
                - generic [ref=e99]: A9
                - generic [ref=e100]: Bodega
            - listitem [ref=e101]:
              - button "A10 Recepción, pendiente" [ref=e103]:
                - generic [ref=e104]: "10"
                - generic [ref=e105]: A10
                - generic [ref=e106]: Recepción
            - listitem [ref=e107]:
              - button "A11 Fin, pendiente" [ref=e108]:
                - generic [ref=e112]: A11
                - generic [ref=e113]: Fin
          - generic [ref=e114]:
            - generic [ref=e115]:
              - generic [ref=e116]:
                - generic [ref=e117]:
                  - generic [ref=e118]:
                    - heading "A2 · Codificación" [level=2] [ref=e120]
                    - generic [ref=e121]: Marketing y codificación
                  - generic [ref=e122]: Etapa actual
                - generic [ref=e123]:
                  - generic [ref=e124]:
                    - term [ref=e125]: Asignada a
                    - definition [ref=e126]: Cualquiera con el rol
                  - generic [ref=e127]:
                    - term [ref=e128]: Entrada
                    - definition [ref=e129]: 15 oct 2026, 09:00
                  - generic [ref=e130]:
                    - term [ref=e131]: Vence
                    - definition [ref=e132]: 20 oct 2026, 16:00
                  - generic [ref=e133]:
                    - term [ref=e134]: Reentradas
                    - definition [ref=e135]: "0"
              - generic [ref=e136]:
                - region [ref=e137]:
                  - heading "Acciones" [level=3] [ref=e139]
                  - button "Enviar" [ref=e141]
                - region [ref=e142]:
                  - heading "Archivos" [level=3] [ref=e143]
                  - paragraph [ref=e144]: Todavía no hay archivos en esta entrada de la etapa.
                  - generic [ref=e145]:
                    - generic [ref=e146]:
                      - group [ref=e147]:
                        - generic [ref=e148]: Tipo de documento
                        - combobox "Tipo de documento" [disabled] [ref=e149]:
                          - generic: Documentos codificados
                        - combobox [disabled] [ref=e150]
                      - group [ref=e151]:
                        - generic [ref=e152]: Archivo
                        - button "Archivo" [disabled]
                        - paragraph [ref=e153]: Hasta 100 MiB (provisional). Los formatos aceptados siguen pendientes del cliente. Tras recargar, vuelve a elegir el mismo archivo para reanudar. Una recepción incompleta no cuenta como documento válido.
                    - generic [ref=e154]:
                      - progressbar "Bytes confirmados de la carga" [ref=e155]
                      - status [ref=e156]: Comprobando el archivo elegido. 0 % recibido por el servidor. La copia a Drive permanece pendiente.
                    - generic [ref=e157]:
                      - status [ref=e158]: Subiendo ficticio.bin…
                      - button "Pausar" [ref=e159]
                      - button "Subir o reanudar" [disabled]
                - region "Observaciones de la etapa" [ref=e160]:
                  - generic [ref=e161]:
                    - group [ref=e162]:
                      - generic [ref=e163]: Nueva observación
                      - textbox "Nueva observación" [ref=e164]
                      - paragraph [ref=e165]: 0 de 4000 caracteres · no cambia la etapa ni sus plazos
                    - button "Publicar observación" [ref=e167]
            - complementary [ref=e168]:
              - region [ref=e169]:
                - heading "Historial" [level=2] [ref=e170]
                - paragraph [ref=e171]: Sin eventos todavía.
  - region "Notifications alt+T"
```

# Test source

```ts
  1  | ﻿import {test,expect} from 'C:/Users/Richard/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/test.mjs';
  2  | import {readFileSync} from 'node:fs';
  3  | import {createHash} from 'node:crypto';
  4  | const f=JSON.parse(readFileSync(new URL('./fixtures.json',import.meta.url)));
  5  | const pedido=f.detalle.id, id=f.adjunto.id;
  6  | async function entorno(page,usuario,handler) {
  7  |  const inesperadas=[];
  8  |  await page.route('**/*',async route=>{
  9  |   const url=new URL(route.request().url());
  10 |   if(url.origin!=='http://127.0.0.1:43182') {inesperadas.push(url.origin);return route.abort();}
  11 |   if(!url.pathname.startsWith('/api/'))return route.continue();
  12 |   const json=body=>route.fulfill({json:body});
  13 |   if(url.pathname.endsWith('/auth/renovar'))return json({tokenAcceso:'ficticio-b2',expiraEn:900,usuario});
  14 |   if(url.pathname.endsWith('/auth/yo'))return json({...usuario,permisos:[]});
  15 |   if(await handler(route,url,json))return;
  16 |   if(url.pathname.endsWith('/historial'))return json([]);
  17 |   if(/\/etapas\/\d+\/archivos$/.test(url.pathname))return json([]);
  18 |   if(url.pathname===`/api/v1/pedidos/${pedido}`)return json(f.detalle);
  19 |   if(url.pathname==='/api/v1/flujos/EC/A')return json(f.flujo);
  20 |   if(url.pathname.startsWith('/api/v1/')) {inesperadas.push(url.pathname);return route.fulfill({status:500,json:{}});}
  21 |  });
  22 |  return inesperadas;
  23 | }
  24 | test('admin ve registro persistido simulado sin envio ni exito inventado',async({page})=>{
  25 |  const i=await entorno(page,f.admin,async(r,u,json)=>{
  26 |   if(u.pathname.endsWith('/notificaciones')) {await json({elementos:[{id,pedidoId:pedido,eventoId:id,destinatario:'admin@ejemplo.test',asunto:'Aviso ficticio B2',estado:'FALLIDA',creadaEn:'2026-10-19T15:00:00Z',enviadaEn:null,intentos:1,ultimoError:'RESULTADO_INCIERTO',resultadoIncierto:true,bloqueo:null}],pagina:0,tamano:20,total:1});return true;}
  27 |   if(u.pathname.endsWith('/copias-fallidas')) {await json([]);return true;}
  28 |  });
  29 |  await page.goto('/notificaciones');
  30 |  await expect(page.getByRole('heading',{name:'Registro de correos'})).toBeVisible();
  31 |  await expect(page.getByRole('cell',{name:'Resultado incierto RESULTADO_INCIERTO'})).toBeVisible();
  32 |  await expect(page.getByRole('cell',{name:'admin@ejemplo.test'})).toBeVisible();
  33 |  await expect(page.getByRole('button',{name:/^(Enviar|Reenviar|Reintentar)/})).toHaveCount(0);
  34 |  expect(i).toEqual([]);
  35 | });
  36 | test('no admin no consulta el registro ni ve el menu de correos',async({page})=>{
  37 |  let consultas=0;
  38 |  await entorno(page,f.ana,async(r,u,json)=>{if(u.pathname.endsWith('/notificaciones')){consultas++;await json({});return true;}});
  39 |  await page.goto('/notificaciones');
  40 |  await expect(page.getByRole('heading',{name:'Sin permiso'})).toBeVisible();
  41 |  await expect(page.getByRole('link',{name:'Correos',exact:true})).toHaveCount(0);
  42 |  expect(consultas).toBe(0);
  43 | });
  44 | test('enlaces solo para copia confirmada; descarga se conserva en backend',async({page})=>{
  45 |  let enlaces=0,descargas=0;
  46 |  const filas=['PENDIENTE','COPIADO','FALLIDO'].map((estadoCopia,k)=>({...f.adjunto,id:id.slice(0,-1)+k,nombre:`copia-${k}.bin`,estadoCopia}));
  47 |  const i=await entorno(page,f.mario,async(r,u,json)=>{
  48 |   if(u.pathname.endsWith('/etapas/2/archivos')){await json(filas);return true;}
  49 |   if(u.pathname.endsWith('/enlace')){enlaces++;await json({url:'https://drive.google.com/file/d/id-ficticio-b2/view'});return true;}
  50 |   if(u.pathname.endsWith('/contenido')){descargas++;await r.fulfill({body:'bytes-ficticios-b2',contentType:'application/octet-stream'});return true;}
  51 |  });
  52 |  await page.goto(`/pedidos/${pedido}`);
  53 |  await expect(page.getByText('Copia a Drive pendiente',{exact:true})).toBeVisible();
  54 |  await expect(page.getByText('Falló la copia',{exact:true})).toBeVisible();
  55 |  await expect(page.getByRole('button',{name:'Consultar enlace de Drive'})).toHaveCount(1);
  56 |  await expect(page.getByRole('link',{name:'Abrir en Drive'})).toHaveCount(0);
  57 |  expect(enlaces).toBe(0);
  58 |  await page.getByRole('button',{name:'Consultar enlace de Drive'}).click();
  59 |  await expect(page.getByRole('link',{name:'Abrir en Drive'})).toHaveAttribute('href','https://drive.google.com/file/d/id-ficticio-b2/view');
  60 |  const d=page.waitForEvent('download');await page.getByRole('button',{name:'Descargar copia-0.bin'}).click();
  61 |  expect((await d).suggestedFilename()).toBe('copia-0.bin');expect(descargas).toBe(1);expect(enlaces).toBe(1);expect(i).toEqual([]);
  62 | });
  63 | test('progreso de dos bloques espera ACK y finalizacion antes de mostrar exito',async({page})=>{
  64 |  const total=4194305,cargaId='00000000-0000-4000-8000-000000000095';let offset=0;const fragmentos=[];let finales=0;
  65 |  let liberar;const gate=new Promise(r=>liberar=r);let recibidos=0;
  66 |  const carga=()=>({id:cargaId,pedidoId:pedido,etapa:2,entradaId:f.adjunto.entradaId,nombre:'ficticio.bin',tipoDocumento:'Documentos codificados',tamanoBytes:total,offsetConfirmado:offset,fragmentoBytes:4194304,estado:'RECIBIENDO',adjuntoId:null,eventoId:null,creadaEn:'2026-10-19T15:00:00Z',actualizadaEn:'2026-10-19T15:00:00Z',fragmentos});
  67 |  const i=await entorno(page,f.mario,async(r,u,json)=>{
  68 |   if(u.pathname.endsWith('/archivos/cargas')){await json(carga());return true;}
  69 |   if(u.pathname.endsWith('/fragmentos')){
  70 |    const req=r.request(),b=req.postDataBuffer(),start=offset;recibidos++;
  71 |    expect(req.headers()['content-range']).toBe(`bytes ${start}-${start+b.length-1}/${total}`);
  72 |    expect(req.headers()['x-fragmento-sha256']).toBe(createHash('sha256').update(b).digest('hex'));
  73 |    if(recibidos===1)await gate;
  74 |    offset+=b.length;fragmentos.push({inicio:start,tamano:b.length,sha256:req.headers()['x-fragmento-sha256']});await json(carga());return true;
  75 |   }
  76 |   if(u.pathname.endsWith('/finalizacion')){finales++;await json(f.adjunto);return true;}
  77 |  });
  78 |  await page.goto(`/pedidos/${pedido}`);await page.getByLabel('Archivo',{exact:true}).setInputFiles({name:'ficticio.bin',mimeType:'application/octet-stream',buffer:Buffer.alloc(total,120)});
  79 |  await page.getByRole('button',{name:'Subir o reanudar'}).click();
  80 |  const progress=page.getByRole('progressbar',{name:'Bytes confirmados de la carga'});
  81 |  await expect.poll(()=>recibidos).toBe(1);await expect(progress).toHaveAttribute('value','0');expect(finales).toBe(0);
> 82 |  await expect(page.getByText(/recibido por el servidor/)).toHaveCount(0);liberar();
     |                                                           ^ Error: expect(locator).toHaveCount(expected) failed
  83 |  await expect.poll(()=>finales).toBe(1);expect(recibidos).toBe(2);expect(offset).toBe(total);
  84 |  await expect(page.getByText(/recibido por el servidor/)).toBeVisible();expect(i).toEqual([]);
  85 | });
  86 | 
```